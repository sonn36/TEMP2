package com.example.demo2.statics;

public class Statics {
    public static int command = -1;
    public static String message = "";
}

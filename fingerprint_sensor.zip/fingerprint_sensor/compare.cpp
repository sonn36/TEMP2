#include "compare.h"

// returns -1 if failed, otherwise returns ID #
int getFingerprintID(Adafruit_Fingerprint finger) {
  uint8_t p = finger.getImage();
  if (p != FINGERPRINT_OK)  return -1;

  p = finger.image2Tz();
  if (p != FINGERPRINT_OK)  return -1;

  Serial.println("Remove finger");
  delay(2000);
  p = 0;
  while (p != FINGERPRINT_NOFINGER) {
    p = finger.getImage();
  }

  p = finger.fingerFastSearch();
  if (p != FINGERPRINT_OK)  return -2;

  // found a match!
  Serial.print("Found ID #"); Serial.print(finger.fingerID);
  Serial.print(" with confidence of "); Serial.println(finger.confidence);
  return finger.fingerID;
}

void compare(Adafruit_Fingerprint finger) {

  finger.getTemplateCount();

  if (finger.templateCount == 0) {
    Serial.print("Sensor doesn't contain any fingerprint data. Please run the 'enroll' example.");
  } else {
    Serial.println("Insert finger");
    int tries = 1;
    int result = getFingerprintID(finger);
    while(result <= -1 && tries <= 5){
      delay(50);
      if(result == -2){
        Serial.println(tries);
        tries = tries + 1;
      }
      result = getFingerprintID(finger);
    }
  }
}




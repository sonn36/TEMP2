#ifndef COMPARE_H
#define COMPARE_H
#include <Arduino.h>
#include <Adafruit_Fingerprint.h>

void compare(Adafruit_Fingerprint finger);
#endif
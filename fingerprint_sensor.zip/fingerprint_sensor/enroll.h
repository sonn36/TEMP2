#ifndef ENROLL_H
#define ENROLL_H
#include <Arduino.h>
#include <Adafruit_Fingerprint.h>

void enroll(Adafruit_Fingerprint finger);
uint8_t readnumber(void);
#endif
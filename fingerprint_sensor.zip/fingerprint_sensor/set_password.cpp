#include "set_password.h"

void set_password(Adafruit_Fingerprint finger) {

  Serial.println("Adafruit fingerprint sensor, change password example");

  // set the data rate for the sensor serial port

  if (finger.verifyPassword()) {
    Serial.println("Found fingerprint sensor!");
  } else {
    Serial.println("Did not find fingerprint sensor :(");
    while (1);
  }

  Serial.print("Set password... ");
  uint8_t p = finger.setPassword(1337);
  if (p == FINGERPRINT_OK) {
    Serial.println("OK"); // Password is set
  } else {
    Serial.println("ERROR"); // Failed to set password
  }

}
  
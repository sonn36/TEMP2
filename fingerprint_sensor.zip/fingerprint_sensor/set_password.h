#ifndef SET_PASSWORD_H
#define SET_PASSWORD_H
#include <Arduino.h>
#include <Adafruit_Fingerprint.h>


void set_password(Adafruit_Fingerprint finger);

#endif